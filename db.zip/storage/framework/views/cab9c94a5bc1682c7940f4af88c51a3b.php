<?php $__env->startSection('namePage', 'eBook'); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-4">

        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md space-y-4">
            
            <div>
                <a href="<?php echo e(route('ebook.index', $folder->slug)); ?>"
                    class="inline-flex items-center px-4 py-2 bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-100 rounded hover:bg-gray-300 dark:hover:bg-gray-600 transition">
                    <i class="fa-solid fa-arrow-left mr-2"></i> Kembali
                </a>
            </div>

            <div class="flex flex-col md:flex-row gap-6">
                
                <div class="w-full md:w-[300px] aspect-[3/4.5] rounded overflow-hidden shadow mx-auto md:mx-0">
                    <img src="<?php echo e(asset($ebook->cover)); ?>" alt="Cover <?php echo e($ebook->title); ?>" class="w-full h-full object-cover" />
                </div>

                
                <div class="flex-1 flex flex-col justify-between space-y-4">
                    <div>
                        <h1 class="text-2xl font-bold mb-2 text-center md:text-left text-gray-900 dark:text-white">
                            <?php echo e($ebook->title); ?>

                        </h1>
                        <p class="text-gray-700 dark:text-gray-300 whitespace-pre-line text-justify mb-3">
                            <?php echo e($ebook->deskripsi); ?>

                        </p>

                        <div class="text-sm text-gray-800 dark:text-gray-200 space-y-1">
                            <p><strong>Dibuat <?php echo e($ebook->created_at->diffForHumans()); ?></strong></p>
                        </div>
                    </div>

                    
                    <div class="space-y-4">
                        <div class="w-full flex flex-col md:flex-row gap-4 mt-4">
                            <?php if(auth()->guard()->check()): ?>
                                <?php $role = Auth::user()->role ?? ''; ?>

                                <?php if($role === 'Admin'): ?>
                                    <a href="<?php echo e(route('ebook.edit', [$folder->slug, $ebook->slug])); ?>"
                                        class="flex-1 px-4 py-2 text-center bg-green-600 text-white rounded hover:bg-green-700 transition flex items-center justify-center">
                                        <i class="fa-solid fa-pen-to-square"></i>
                                        <span class="hidden md:inline ml-2 text-center">Edit e-Book</span>
                                    </a>

                                    <button onclick="openModalDelete()"
                                        class="flex-1 px-4 py-2 text-center bg-red-600 text-white rounded hover:bg-red-700 transition flex items-center justify-center">
                                        <i class="fa-solid fa-trash"></i>
                                        <span class="hidden md:inline ml-2 text-center">Delete e-Book</span>
                                    </button>
                                <?php else: ?>
                                    <a href="<?php echo e(asset($ebook->file)); ?>" target="_blank"
                                        class="flex-1 px-4 py-2 text-center bg-blue-600 text-white rounded hover:bg-blue-700 transition flex items-center justify-center">
                                        <i class="fa-solid fa-download"></i>
                                        <span class="hidden md:inline ml-2 text-center">Download e-Book</span>
                                    </a>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if(auth()->guard()->check()): ?>
            <?php $role = Auth::user()->role ?? ''; ?>
        <?php endif; ?>

        <div class="space-y-4">

            <?php if($ebook->postTestSessions->count() > 0): ?>
                
                <?php $__currentLoopData = $ebook->postTestSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex items-center justify-between mb-4">
                        <div class="flex items-center gap-5">
                            <div class="bg-slate-200 dark:bg-gray-900 text-gray-800 dark:text-gray-100 p-4 rounded-full">
                                <i class="fa-regular fa-circle-question fa-3x"></i>
                            </div>
                            <h2 class="text-lg font-bold text-center text-gray-900 dark:text-white">
                                <?php echo e($session->title); ?>

                            </h2>
                        </div>

                        <div class="flex items-center gap-4">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if($role === 'Admin'): ?>
                                    
                                    <a href="<?php echo e(route('quiz.index', [$folder->slug, $ebook->slug])); ?>"
                                        class="px-4 py-2 text-center bg-blue-600 text-white rounded hover:bg-blue-700 transition">
                                        Tambah Pertanyaan
                                    </a>
                                <?php else: ?>
                                    
                                    <?php
                                        $result = $session->results->where('user_id', auth()->id())->first();
                                    ?>

                                    <?php if(session('info')): ?>
                                        <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 5000)"
                                            class="text-xs bg-red-200 text-red-800 py-1 px-3 rounded-lg">
                                            <?php echo e(session('info')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <?php
                                        $result = $session->results->first();
                                    ?>

                                    <?php if($result): ?>
                                        <div class="text-xs bg-green-200 text-green-800 py-1 px-3 rounded-lg">
                                            Skor: <?php echo e($result->score); ?>/100
                                        </div>
                                        <button disabled class="px-4 py-2 bg-gray-400 text-white rounded cursor-not-allowed">
                                            Sudah Dikerjakan
                                        </button>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('posttest.show', [
                                            'folderSlug' => $folder->slug,
                                            'ebookSlug' => $ebook->slug,
                                            'session' => $session->id,
                                        ])); ?>"
                                            class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition">
                                            Kerjakan Post-Test
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                
                <?php if(auth()->guard()->check()): ?>
                    <?php if($role === 'Admin'): ?>
                        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md flex items-center justify-between mb-4">
                            <div class="flex items-center gap-5">
                                <div class="bg-slate-200 dark:bg-gray-900 text-gray-800 dark:text-gray-100 p-4 rounded-full">
                                    <i class="fa-solid fa-circle-plus fa-3x"></i>
                                </div>
                                <h2 class="text-lg font-bold text-center text-gray-900 dark:text-white">
                                    Belum ada Post-Test Session
                                </h2>
                            </div>
                            <a href="<?php echo e(route('quiz.index', [$folder->slug, $ebook->slug])); ?>"
                                class="px-4 py-2 text-center bg-blue-600 text-white rounded hover:bg-blue-700 transition">
                                Tambah Pertanyaan
                            </a>
                        </div>
                    <?php else: ?>
                        <div
                            class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md text-center text-gray-500 dark:text-gray-300">
                            Tidak ada Post-Test Session untuk eBook ini.
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>

        </div>

    </div>

    
    <div id="modalDelete"
        class="fixed inset-0 z-50 hidden bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center">
        <div class="bg-white dark:bg-gray-800 rounded-xl shadow-2xl w-full max-w-md">
            <div class="px-6 py-5">
                <h3 class="text-xl font-bold text-red-500">
                    <i class="fa-solid fa-triangle-exclamation mr-2"></i>Konfirmasi Hapus
                </h3>
            </div>

            <div class="px-6 py-4 border-t border-b dark:border-gray-700">
                <p class="text-gray-700 dark:text-gray-300">
                    Apakah Anda yakin ingin menghapus e-Book <strong><?php echo e($ebook->judul); ?></strong>? Tindakan ini tidak dapat
                    dibatalkan.
                </p>
            </div>

            <div class="flex justify-end gap-3 px-6 py-4">
                <button onclick="closeModalDelete()"
                    class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded-md dark:bg-gray-600 dark:text-white">
                    Batal
                </button>
                <form id="deleteForm" action="<?php echo e(route('ebook.destroy', [$folder->slug, $ebook->slug])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md">
                        Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function openModalDelete() {
            document.getElementById('modalDelete').classList.remove('hidden');
            document.body.classList.add('overflow-hidden');
        }

        function closeModalDelete() {
            document.getElementById('modalDelete').classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/ebook/show.blade.php ENDPATH**/ ?>