<?php $__env->startSection('namePage', 'Tambah Pertanyaan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white dark:bg-gray-800 p-6 rounded shadow text-gray-900 dark:text-gray-100">
        <h2 class="text-xl font-semibold mb-4">Tambah Pertanyaan</h2>

        <form id="questionForm" method="POST"
            action="<?php echo e(route('quiz.add-question-store', ['folderSlug' => $folderSlug, 'ebookSlug' => $ebookSlug, 'sessionId' => $session->id])); ?>">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="question"
                    class="text-sm font-medium block mb-1 text-gray-700 dark:text-gray-300">Pertanyaan</label>
                <textarea id="question" name="question"
                    class="summernote w-full rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-100"><?php echo e(old('question')); ?></textarea>
                <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php $__currentLoopData = ['A', 'B', 'C', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Pilihan
                        <?php echo e($opt); ?></label>
                    <input type="text" name="option_<?php echo e(strtolower($opt)); ?>"
                        class="w-full rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        value="<?php echo e(old('option_' . strtolower($opt))); ?>">
                    <?php $__errorArgs = ['option_' . strtolower($opt)];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="mb-4">
                <label for="correct_option" class="block text-sm font-medium mb-1 text-gray-700 dark:text-gray-300">Jawaban
                    Benar</label>
                <select name="correct_option" id="correct_option"
                    class="w-full rounded border border-gray-300 dark:border-gray-600 dark:bg-gray-900 dark:text-gray-100 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">-- Pilih --</option>
                    <?php $__currentLoopData = ['A', 'B', 'C', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($opt); ?>" <?php echo e(old('correct_option') == $opt ? 'selected' : ''); ?>>
                            <?php echo e($opt); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['correct_option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="flex justify-between items-center mt-6">
                <a href="<?php echo e(route('quiz.index', [
                    'folderSlug' => $folderSlug,
                    'ebookSlug' => $ebookSlug,
                ])); ?>"
                    class="text-sm text-gray-500 dark:text-gray-400 hover:underline">← Kembali</a>

                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                    Simpan
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                height: 300,
                callbacks: {
                    onImageUpload: function(files) {
                        let data = new FormData();
                        data.append('image', files[0]);
                        data.append('_token', '<?php echo e(csrf_token()); ?>');

                        $.ajax({
                            url: "<?php echo e(route('summernote.upload')); ?>",
                            type: 'POST',
                            data: data,
                            contentType: false,
                            processData: false,
                            success: function(url) {
                                $('.summernote').summernote('insertImage', url);
                            }
                        });
                    },
                    onMediaDelete: function(target) {
                        $.ajax({
                            url: "<?php echo e(route('summernote.delete')); ?>",
                            type: 'POST',
                            data: {
                                _token: '<?php echo e(csrf_token()); ?>',
                                image: target[0].src
                            },
                            success: function(res) {
                                console.log('Gambar dihapus:', res);
                            }
                        });
                    }
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/quiz/add-question.blade.php ENDPATH**/ ?>