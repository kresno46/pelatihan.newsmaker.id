<?php $__env->startSection('namePage', 'Riwayat Post Test'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md">
        <h2 class="text-3xl font-bold mb-6 text-center text-gray-800 dark:text-white">📚 Riwayat Post Test Anda</h2>

        <?php if($results->isEmpty()): ?>
            <div class="text-center text-gray-500 dark:text-gray-300">
                Belum ada post test yang pernah dikerjakan.
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table
                    class="min-w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden">
                    <thead class="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
                        <tr>
                            <th class="px-4 py-3 text-left">📘 Ebook</th>
                            <th class="px-4 py-3 text-left">📝 Sesi</th>
                            <th class="px-4 py-3 text-left">⏱️ Durasi</th>
                            <th class="px-4 py-3 text-left">📊 Skor</th>
                            <th class="px-4 py-3 text-left">🗓️ Tanggal</th>
                            <th class="px-4 py-3 text-center">🔍 Detail</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-800 dark:text-gray-100 divide-y divide-gray-200 dark:divide-gray-700">
                        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
                                <td class="px-4 py-3"><?php echo e($result->ebook->title ?? '-'); ?></td>
                                <td class="px-4 py-3"><?php echo e($result->session->title ?? '-'); ?></td>
                                <td class="px-4 py-3"><?php echo e($result->session->duration ?? '-'); ?> menit</td>
                                <td class="px-4 py-3 font-semibold text-green-600 dark:text-green-400">
                                    <?php echo e($result->score); ?>/100
                                </td>
                                <td class="px-4 py-3"><?php echo e($result->created_at->format('d M Y, H:i')); ?></td>
                                <td class="px-4 py-3 text-center">
                                    <a href="<?php echo e(route('riwayat.show', $result->id)); ?>"
                                        class="text-blue-600 hover:underline">Lihat</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/riwayat/index.blade.php ENDPATH**/ ?>