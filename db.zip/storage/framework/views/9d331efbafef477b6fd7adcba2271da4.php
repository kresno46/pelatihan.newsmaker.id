<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['user']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['user']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php
    $requiredFields = [
        'name' => 'Nama Lengkap',
        'email' => 'Email',
        'jenis_kelamin' => 'Jenis Kelamin',
        'tempat_lahir' => 'Tempat Lahir',
        'tanggal_lahir' => 'Tanggal Lahir',
        'warga_negara' => 'Warga Negara',
        'alamat' => 'Alamat',
        'no_tlp' => 'Nomor Telepon',
        'pekerjaan' => 'Pekerjaan',
    ];

    $missingFields = [];
    foreach ($requiredFields as $field => $label) {
        if (empty($user->$field)) {
            $missingFields[] = "Data $label belum diisi";
        }
    }
?>

<?php if(count($missingFields) > 0): ?>
    <ul <?php echo e($attributes->merge(['class' => 'mt-4 list-disc list-inside text-red-500'])); ?>>
        <?php $__currentLoopData = $missingFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($message); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>
<?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/components/missing-fields-alert.blade.php ENDPATH**/ ?>