<?php $__env->startSection('namePage', $user->name . ' - Hasil Post Test'); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="max-w-4xl mx-auto p-8 bg-white dark:bg-gray-900 rounded-2xl shadow-lg mt-10 border border-gray-200 dark:border-gray-700">
        <div class="text-center mb-10">
            <h2 class="text-4xl font-bold text-gray-800 dark:text-white">📊 Hasil Post Test</h2>
            <p class="text-gray-500 dark:text-gray-400 mt-2 text-lg">Detail lengkap hasil pengerjaan Anda</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm md:text-base">
            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">👤 <span class="font-semibold">Nama</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($user->name ?? '-'); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">📚 <span class="font-semibold">Ebook</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($session->ebook->title ?? '-'); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">📝 <span class="font-semibold">Sesi Post Test</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($session->title ?? '-'); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">⏱️ <span class="font-semibold">Durasi</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($session->duration ?? '-'); ?> menit</p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <?php
                    $correct = round(($result->score / 100) * $session->questions->count());
                    $pass = $result->score >= 70;
                ?>
                <p class="text-gray-500 dark:text-gray-400">✅ <span class="font-semibold">Jawaban Benar</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($correct); ?> dari <?php echo e($session->questions->count()); ?>

                    soal</p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">📈 <span class="font-semibold">Nilai Akhir</span></p>
                <p
                    class="text-2xl font-extrabold <?php echo e($pass ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'); ?>">
                    <?php echo e($result->score ?? '-'); ?>/100
                </p>
                <p class="mt-1 text-sm <?php echo e($pass ? 'text-green-500' : 'text-red-500'); ?>">
                    <?php echo e($pass ? 'Lulus ✅' : 'Tidak Lulus ❌'); ?>

                </p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
                <p class="text-gray-500 dark:text-gray-400">🗓️ <span class="font-semibold">Tanggal Pengerjaan</span></p>
                <p class="text-gray-800 dark:text-white text-lg"><?php echo e($result->created_at->translatedFormat('d F Y - H:i')); ?>

                </p>
            </div>
        </div>

        <div class="text-center mt-10">
            <a href="<?php echo e(route('ebook.show', [$folderSlug, $ebookSlug])); ?>"
                class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2 rounded-lg transition-all">
                ← Kembali ke Halaman Ebook
            </a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/post-test/result.blade.php ENDPATH**/ ?>