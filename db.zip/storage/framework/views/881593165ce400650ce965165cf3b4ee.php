

<?php $__env->startSection('namePage', 'ebook'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-lg">

        
        <div class="w-full flex items-center gap-2 mb-5">
            <form action="<?php echo e(route('folder.index')); ?>" method="GET" class="flex items-center gap-2 flex-grow">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari Nama Folder..."
                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm text-gray-900 dark:text-gray-100 bg-white dark:bg-gray-800" />
            </form>

            <a href="<?php echo e(route('folder.index')); ?>"
                class="bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-600 transition">
                Reset
            </a>

            <?php if(Auth::user()->role === 'Admin'): ?>
                <a href="<?php echo e(route('folder.create')); ?>"
                    class="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-600 transition">
                    <span class="block sm:hidden">+</span>
                    <span class="hidden sm:block">Tambah Folder</span>
                </a>
            <?php endif; ?>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <?php $__empty_1 = true; $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div
                    class="shadow-lg rounded-2xl bg-zinc-50 dark:bg-zinc-700 dark:text-gray-100 p-6 space-y-4 transition-all border dark:border-zinc-800 duration-300 hover:shadow-xl h-full">

                    <div class="flex flex-col md:flex-row items-start md:items-center gap-6">
                        <div class="py-4 px-5 bg-blue-300 dark:bg-blue-800 rounded-full">
                            <i class="fa-solid fa-book-bookmark fa-2x text-blue-500 dark:text-blue-300"></i>
                        </div>

                        <div class="flex-1">
                            <h1 class="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-2">
                                <?php echo e($folder->folder_name); ?>

                            </h1>

                            <p class="text-gray-600 dark:text-gray-300 text-sm leading-relaxed line-clamp-1 mb-1">
                                <?php echo e($folder->Deskripsi ?? 'Tidak ada deskripsi.'); ?>

                            </p>

                            <p class="text-gray-600 dark:text-gray-300 text-sm">
                                <i class="fa-solid fa-book-open mr-1"></i>
                                <?php echo e($folder->ebooks_count); ?> eBook dalam materi ini
                            </p>
                        </div>
                    </div>

                    <div class="flex items-stretch gap-2 mt-4">
                        
                        <a href="<?php echo e(route('ebook.index', $folder->slug)); ?>"
                            class="w-full px-4 py-1 bg-blue-500 text-white rounded-lg text-sm hover:bg-blue-600 transition text-center block">
                            Lihat
                        </a>

                        <?php if(Auth::user()->role === 'Admin'): ?>
                            
                            <a href="<?php echo e(route('folder.edit', $folder->slug)); ?>"
                                class="w-full px-4 py-1 bg-yellow-500 text-white rounded-lg text-sm hover:bg-yellow-600 transition text-center block">
                                Edit
                            </a>

                            
                            <form action="<?php echo e(route('folder.destroy', $folder->id)); ?>" method="POST" class="w-full">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Yakin ingin menghapus folder ini?')"
                                    class="w-full px-4 py-1 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600 transition text-center">
                                    Hapus
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-1 md:col-span-2 lg:col-span-4 text-center py-10">
                    <p class="text-gray-500">Tidak ada folder eBook ditemukan.</p>
                </div>
            <?php endif; ?>
        </div>

        
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mt-6 gap-2">
            <?php if($folders->total() > 8): ?>
                <div class="w-full">
                    <?php echo e($folders->appends(['search' => request('search')])->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-sm text-gray-600 dark:text-gray-300 p-2">
                    Menampilkan
                    <?php if($folders->total() > 0): ?>
                        <?php echo e($folders->firstItem()); ?> sampai <?php echo e($folders->lastItem()); ?> dari total <?php echo e($folders->total()); ?>

                        hasil
                    <?php else: ?>
                        0 sampai 0 dari total 0 hasil
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/folder/index.blade.php ENDPATH**/ ?>