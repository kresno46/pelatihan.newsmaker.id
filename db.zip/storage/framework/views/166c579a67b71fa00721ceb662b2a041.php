<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\NM_Edukasi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>