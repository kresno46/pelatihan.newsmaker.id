

<?php $__env->startSection('namePage', 'Detail Hasil - ' . $laporan->user->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-6">
        
        <a href="<?php echo e(route('laporan.index')); ?>"
            class="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-white rounded hover:bg-gray-200 dark:hover:bg-gray-600 transition">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>

        
        <div class="md:col-span-2 bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 space-y-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-900 dark:text-white">
                    <?php echo e($laporan->ebook->title); ?> - <?php echo e($laporan->user->name); ?>

                </h2>
            </div>

            <?php
                $jumlahSoal = $laporan->session->questions->count() ?? 0;
                $jawabanBenar = round(($laporan->score / 100) * $jumlahSoal);
            ?>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-base text-gray-700 dark:text-gray-300">
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-user','label' => 'Peserta','value' => $laporan->user->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-user','label' => 'Peserta','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->user->name)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-envelope','label' => 'Email','value' => $laporan->user->email]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-envelope','label' => 'Email','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->user->email)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-phone','label' => 'No. Telepon','value' => $laporan->user->no_tlp]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-phone','label' => 'No. Telepon','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->user->no_tlp)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-layer-group','label' => 'Nama Sesi','value' => $laporan->session->title ?? '-']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-layer-group','label' => 'Nama Sesi','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->session->title ?? '-')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-calendar-alt','label' => 'Tanggal Pengerjaan','value' => $laporan->created_at->format('d F Y')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-calendar-alt','label' => 'Tanggal Pengerjaan','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->created_at->format('d F Y'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-clock','label' => 'Durasi Sesi','value' => $laporan->session->duration . ' menit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-clock','label' => 'Durasi Sesi','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($laporan->session->duration . ' menit')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
            </div>

            <?php if (isset($component)) { $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.laporan-info','data' => ['icon' => 'fa-check-circle','label' => 'Jawaban Benar','value' => $jawabanBenar . ' dari ' . $jumlahSoal . ' soal']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('laporan-info'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['icon' => 'fa-check-circle','label' => 'Jawaban Benar','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($jawabanBenar . ' dari ' . $jumlahSoal . ' soal')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $attributes = $__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__attributesOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef)): ?>
<?php $component = $__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef; ?>
<?php unset($__componentOriginal2d17b55d210bf2358b1e5a203c8d30ef); ?>
<?php endif; ?>

            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <?php
                    $colorClass =
                        $laporan->score >= 85
                            ? 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300'
                            : ($laporan->score <= 50
                                ? 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300'
                                : 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300');
                ?>

                <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 flex items-center justify-between">
                    <div class="flex flex-col gap-3">
                        <p class="text-gray-500"><i class="fa-solid fa-star me-2"></i>Skor</p>
                        <span class="text-4xl text-center font-bold <?php echo e($colorClass); ?> px-4 py-1 rounded-full">
                            <?php echo e($laporan->score); ?>/100
                        </span>
                    </div>
                </div>

                <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 flex items-center justify-between">
                    <div class="flex flex-col gap-3">
                        <p class="text-gray-500"><i class="fa-solid fa-certificate me-2"></i>Grade</p>
                        <span class="text-4xl text-center font-bold <?php echo e($colorClass); ?> px-4 py-1 rounded-full">
                            <?php echo e($laporan->score >= 85 ? 'A' : ($laporan->score >= 70 ? 'B' : ($laporan->score >= 50 ? 'C' : 'D'))); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/laporan/show.blade.php ENDPATH**/ ?>