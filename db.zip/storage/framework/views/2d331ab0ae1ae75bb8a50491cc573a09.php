<?php $__env->startSection('namePage', 'Kuis Attempt: ' . $session->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="space-y-5">
        <div class="p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h2 class="text-xl font-bold mb-4 text-gray-900 dark:text-white"><?php echo e($session->title); ?></h2>
            <div id="timer" class="text-red-600 dark:text-red-400 font-semibold">
                Sisa waktu: <span id="countdown"></span>
            </div>
        </div>

        <form id="quizForm"
            action="<?php echo e(route('posttest.submit', [
                'folderSlug' => $folderSlug,
                'ebookSlug' => $ebook->slug,
                'session' => $session->id,
            ])); ?>"
            method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
                    <div>
                        <div class="font-medium text-gray-800 dark:text-gray-100"><?php echo $question->question; ?></div>
                        <?php $__currentLoopData = ['A', 'B', 'C', 'D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $opt_text = $question->{'option_' . strtolower($opt)}; ?>
                            <?php if($opt_text): ?>
                                <label class="block text-gray-700 dark:text-gray-300">
                                    <input type="radio" name="answer[<?php echo e($question->id); ?>]" value="<?php echo e($opt); ?>"
                                        required class="mr-2" data-question="<?php echo e($question->id); ?>">
                                    <?php echo e($opt); ?>. <?php echo e($opt_text); ?>

                                </label>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Tombol untuk buka modal -->
            <button type="button" onclick="showModal()"
                class="bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white px-4 py-2 rounded w-full">
                Submit
            </button>
        </form>
    </div>

    <!-- Modal Konfirmasi -->
    <div id="confirmModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg w-full max-w-md">
            <h3 class="text-lg font-semibold text-gray-800 dark:text-white mb-4">Konfirmasi</h3>
            <p class="text-gray-600 dark:text-gray-300 mb-6">Apakah Anda yakin ingin menyelesaikan kuis ini?</p>
            <div class="flex justify-end space-x-3">
                <button type="button" onclick="hideModal()"
                    class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">Batal</button>

                <!-- Tombol submit langsung -->
                <button type="submit" form="quizForm" onclick="clearData()"
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                    Ya, Selesai
                </button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        const countdownEl = document.getElementById('countdown');
        const quizForm = document.getElementById('quizForm');
        const sessionKey = 'quiz_timer_<?php echo e($session->id); ?>';
        const answerKey = 'quiz_answers_<?php echo e($session->id); ?>';
        const duration = <?php echo e($session->duration); ?> * 60;
        const savedStartTime = localStorage.getItem(sessionKey);
        const startTime = savedStartTime ? parseInt(savedStartTime) : Date.now();

        // Save start time if not already saved
        if (!savedStartTime) localStorage.setItem(sessionKey, startTime);

        function updateTimer() {
            const elapsed = Math.floor((Date.now() - startTime) / 1000);
            const remaining = duration - elapsed;

            if (remaining <= 0) {
                countdownEl.textContent = '0m 0s';
                alert('Waktu habis! Jawaban Anda akan dikirim otomatis.');
                clearData();
                quizForm.submit();
                return;
            }

            const minutes = Math.floor(remaining / 60);
            const seconds = remaining % 60;
            countdownEl.textContent = `${minutes}m ${seconds}s`;
        }

        setInterval(updateTimer, 1000);
        updateTimer();

        // Load & Simpan Jawaban
        const radios = quizForm.querySelectorAll('input[type=radio]');
        let answers = JSON.parse(localStorage.getItem(answerKey) || '{}');

        radios.forEach(radio => {
            const qid = radio.dataset.question;
            if (answers[qid] === radio.value) {
                radio.checked = true;
            }
            radio.addEventListener('change', () => {
                answers[qid] = radio.value;
                localStorage.setItem(answerKey, JSON.stringify(answers));
            });
        });

        function clearData() {
            localStorage.removeItem(sessionKey);
            localStorage.removeItem(answerKey);
        }

        // Modal Logic
        function showModal() {
            document.getElementById('confirmModal').classList.remove('hidden');
        }

        function hideModal() {
            document.getElementById('confirmModal').classList.add('hidden');
        }

        // Cegah submit via Enter
        quizForm.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/post-test/index.blade.php ENDPATH**/ ?>