<?php $__env->startSection('namePage', 'eBook'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-lg">

        
        <div class="w-full flex items-center gap-2 mb-5">
            <a href="<?php echo e(route('folder.index')); ?>"
                class="bg-gray-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-600 transition cursor-pointer">
                <span class="block sm:hidden"><i class="fa-solid fa-arrow-left"></i></span>
                <span class="hidden sm:block">Kembali</span>
            </a>

            <form action="<?php echo e(route('ebook.index', $folder->slug)); ?>" method="GET" class="flex items-center gap-2 flex-grow">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                    placeholder="Cari judul atau penulis eBook..."
                    class="w-full px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm text-gray-900 dark:text-gray-100 bg-white dark:bg-gray-800" />
            </form>

            <a href="<?php echo e(route('ebook.index', $folder->slug)); ?>"
                class="bg-red-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-600 transition cursor-pointer">
                Reset
            </a>

            <?php if(Auth::user()->role === 'Admin'): ?>
                <a href="<?php echo e(route('ebook.create', $folder->slug)); ?>"
                    class="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-blue-600 transition cursor-pointer">
                    <span class="block sm:hidden">+</span>
                    <span class="hidden sm:block">Tambah e-Book</span>
                </a>
            <?php endif; ?>
        </div>

        
        <div class="flex flex-col divide-y divide-gray-200 dark:divide-gray-600">
            <?php $__empty_1 = true; $__currentLoopData = $ebooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('ebook.show', [$folder->slug, $item->slug])); ?>"
                    class="flex items-start gap-4 py-4 px-4 transition rounded-lg md:rounded-none
                           <?php if($index % 2 === 0): ?> bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 
                           <?php else: ?> bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 <?php endif; ?>">

                    
                    <div class="w-16 h-24 overflow-hidden rounded shadow flex-shrink-0">
                        <img src="<?php echo e(asset($item->cover)); ?>" alt="Cover <?php echo e($item->title); ?>"
                            class="object-cover w-full h-full" />
                    </div>

                    
                    <div class="flex-1">
                        <h3 class="font-semibold text-gray-900 dark:text-gray-100 text-base mb-1"><?php echo e($item->title); ?></h3>
                        <p class="text-sm text-gray-600 dark:text-gray-300 line-clamp-2 mb-1">
                            <?php echo e($item->deskripsi ?? 'Tidak ada deskripsi.'); ?>

                        </p>
                        <p class="text-xs text-gray-500 dark:text-gray-400">
                            (NewsMaker 23)
                            <?php echo e($item->created_at->diffForHumans()); ?>

                        </p>
                    </div>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-10 text-gray-500 dark:text-gray-400">
                    Tidak ada ebook ditemukan.
                </div>
            <?php endif; ?>
        </div>

        
        <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mt-6 gap-2">
            <?php if($ebooks->total() > 8): ?>
                <div class="w-full">
                    <?php echo e($ebooks->appends(['search' => request('search')])->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-sm text-gray-600 dark:text-gray-300 p-2">
                    Menampilkan
                    <?php if($ebooks->total() > 0): ?>
                        <?php echo e($ebooks->firstItem()); ?> sampai <?php echo e($ebooks->lastItem()); ?> dari total <?php echo e($ebooks->total()); ?>

                        hasil
                    <?php else: ?>
                        0 sampai 0 dari total 0 hasil
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\NM_Edukasi\resources\views/ebook/index.blade.php ENDPATH**/ ?>